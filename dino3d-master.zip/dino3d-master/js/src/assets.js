/**
 * Scene assets.
 */

//= geometry/ground.js
//= geometry/ground_bg.js
//= geometry/dyno.js
//= geometry/dyno_band.js
//= geometry/dyno_wow.js
//= geometry/cactus.js
//= geometry/ptero.js

//= geometry/rocks.js
//= geometry/flowers.js
//= geometry/misc.js

//= textures/ground.js